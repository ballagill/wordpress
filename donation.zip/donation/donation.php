<?php
/*
Plugin Name: Donation Settings
Description: To handle the Danation Settins.
Version: 1.1.1
Author: Ech
*/
?>
<?php
// create custom plugin settings menu
add_action('admin_menu', 'my_cool_plugin_create_menu');

function my_cool_plugin_create_menu() {

	//create new top-level menu
	add_menu_page('My Cool Plugin Settings', 'Donation Settings', 'administrator', __FILE__, 'my_cool_plugin_settings_page' , plugins_url('/images/icon.png', __FILE__) );

	//call register settings function
	add_action( 'admin_init', 'register_my_cool_plugin_settings' );
}


function register_my_cool_plugin_settings() {
	//register our settings
	register_setting( 'my-cool-plugin-settings-group', 'paypal_business_account_email' );
	register_setting( 'my-cool-plugin-settings-group', 'total_donation_amount' );
	register_setting( 'my-cool-plugin-settings-group', 'total_donator' );
	register_setting( 'my-cool-plugin-settings-group', 'new_donation_amount' );
	register_setting( 'my-cool-plugin-settings-group', 'new_donator' );
	register_setting( 'my-cool-plugin-settings-group', 'hours_to_go' );
	register_setting( 'my-cool-plugin-settings-group', 'progress_bar_text' );
	register_setting( 'my-cool-plugin-settings-group', 'number_color' );
	register_setting( 'my-cool-plugin-settings-group', 'text_color' );
	register_setting( 'my-cool-plugin-settings-group', 'progress_color' );
	register_setting( 'my-cool-plugin-settings-group', 'paypal_mode' );
	
}

function my_cool_plugin_settings_page() {
	
	
$addnewvalues = $_REQUEST['addnewvalues'];
if(isset($addnewvalues)){	
$new_donation_amount = esc_attr( get_option('new_donation_amount') );
$new_donator = esc_attr( get_option('new_donator') );
$total_donation_amount = esc_attr( get_option('total_donation_amount') );
$total_donator = esc_attr( get_option('total_donator') );
$new_amount = $new_donation_amount + $total_donation_amount;
$new_donator = $new_donator + $total_donator;	
update_option( 'total_donation_amount', $new_amount );
update_option( 'total_donator', $new_donator );
update_option( 'new_donation_amount', '0' );
update_option( 'new_donator', '0' );
}	
?>
<div class="wrap">
<h2>Donation Settings</h2>
<form method="post" action="options.php">
    <?php settings_fields( 'my-cool-plugin-settings-group' ); ?>
    <?php do_settings_sections( 'my-cool-plugin-settings-group' ); ?>
    <table class="form-table">
	    <tr valign="top">
        <th scope="row">Paypal Business Account Email</th>
        <td><input type="text" style="width: 250px;" name="paypal_business_account_email" value="<?php echo esc_attr( get_option('paypal_business_account_email') ); ?>" /></td>
        </tr>
	
	
        <tr valign="top">
        <th scope="row">Total Donation Amount</th>
        <td><input type="text" name="total_donation_amount" value="<?php echo esc_attr( get_option('total_donation_amount') ); ?>" /></td>
        </tr>
         
        <tr valign="top">
        <th scope="row">Total Donator</th>
        <td><input type="text" name="total_donator" value="<?php echo esc_attr( get_option('total_donator') ); ?>" /></td>
        </tr>
		
		 <tr valign="top">
        <th scope="row">New Donation Amount</th>
        <td><input type="text" name="new_donation_amount" value="<?php echo esc_attr( get_option('new_donation_amount') ); ?>" /></td>
        </tr>
		
		
		 <tr valign="top">
        <th scope="row">New Donator</th>
        <td><input type="text" name="new_donator" value="<?php echo esc_attr( get_option('new_donator') ); ?>" /></td>
        </tr>
		
		<tr valign="top">
        <th scope="row">Hours To Go</th>
        <td><input type="text" name="hours_to_go" value="<?php echo esc_attr( get_option('hours_to_go') ); ?>" /></td>
        </tr>
        
		<tr valign="top">
        <th scope="row">Progress bar text</th>
        <td><input type="text" style="width: 350px;" name="progress_bar_text" value="<?php echo esc_attr( get_option('progress_bar_text') ); ?>" /></td>
        </tr>
		
		<tr valign="top">
        <th scope="row">Number Color</th>
        <td><input type="color" name="number_color" value="<?php echo esc_attr( get_option('number_color') ); ?>" /></td>
        </tr>
		
		<tr valign="top">
        <th scope="row">Text Color</th>
        <td><input type="color" name="text_color" value="<?php echo esc_attr( get_option('text_color') ); ?>" /></td>
        </tr>
		
		<tr valign="top">
        <th scope="row">Progress Bar Color</th>
        <td><input type="color" name="progress_color" value="<?php echo esc_attr( get_option('progress_color') ); ?>" /></td>
        </tr>
		
		<tr valign="top">
        <th scope="row">Activate Sandbox Paypal</th>
        <td><input type="radio" name="paypal_mode" <?php if(esc_attr( get_option('paypal_mode') )=="sandbox.paypal"){echo "checked='checked'";} ?> value="sandbox.paypal" /></td>
        </tr>
		
		
		<tr valign="top">
        <th scope="row">Activate Live Paypal</th>
        <td><input type="radio" name="paypal_mode" <?php if(esc_attr( get_option('paypal_mode') )=="paypal"){echo "checked='checked'";} ?> value="paypal" /></td>
        </tr>
     
    </table>
    
    <?php submit_button(); ?>

</form>

<div class="updatedata">
<h2>Press the below button to add the new entries to total.</h2>
<form method="post" action="">
<input type="submit" value="Add New Entries" name="addnewvalues">
</form>
<style>
.updatedata input {
    cursor: pointer;
    background-color: #0085ba;
    color: #ffffff;
    padding: 6px 10px;
    border: none;
    border-radius: 5px;
}
</style>
</div>
</div>
<?php } ?>