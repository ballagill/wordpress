<?php
   /*
   Plugin Name: Mobile API
   Version: 1.2
   */

	define( 'MAPI_BASE_FILE', __FILE__ );
	define( 'MAPI_DIR', dirname( __FILE__ ) );
	/*function myplugin_activate() 
	{
		global $wpdb;
		$qry = "CREATE TABLE ".$wpdb->prefix."`video_urls` (
		  `id` int(11) NOT NULL PRIMARY KEY AUTO_INCREMENT,
		  `video_url` varchar(2000) COLLATE utf8mb4_unicode_ci NOT NULL,
		  `video_description` text COLLATE utf8mb4_unicode_ci NOT NULL,
		  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
		) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
		$wpdb->get_results( $qry );
	}
	register_activation_hook( __FILE__, 'myplugin_activate' );*/
	
 
	// function to create the DB / Options / Defaults					
	function your_plugin_options_install() {
	   	global $wpdb;
	   	$your_db_name = $wpdb->prefix . 'video_urls';
	 
		// create the ECPT metabox database table
		
		$sql = "CREATE TABLE IF NOT EXISTS ".$your_db_name."(
					  `id` int(11) NOT NULL PRIMARY KEY AUTO_INCREMENT,
					  `title` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
					  `video_url` varchar(2000) COLLATE utf8mb4_unicode_ci NOT NULL,
					  `video_description` text COLLATE utf8mb4_unicode_ci NOT NULL,
					  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
					) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;";
	 
			require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
			dbDelta($sql);
		
	 
	}
	// run the install scripts upon plugin activation
	register_activation_hook(__FILE__,'your_plugin_options_install');
	require_once( MAPI_DIR . '/classes/api_class.php' );
