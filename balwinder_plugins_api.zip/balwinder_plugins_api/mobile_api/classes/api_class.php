<?php 
	function wpdocs_register_my_custom_menu_page(){
		add_menu_page( 
			__( 'Add Vimeo Video', 'textdomain' ),
			'Add Vimeo Video',
			'manage_options',
			'vimeo_video_links',
			'vimeo_videos','dashicons-format-video',
			6
		);
		add_submenu_page('vimeo_video_links',
			__( 'All Vimeo Video', 'textdomain' ),
			'All vimeo video',
			'manage_options',
			'vimeo_video_link',
			'dashboard_videos_data'
		); 
	}
	add_action( 'admin_menu', 'wpdocs_register_my_custom_menu_page' );

	function dashboard_videos_data()
	{
		$videos = all_vimeo_videos();
		/*echo "<pre>";
		print_r($videos);
		echo "</pre>";*/
		 ?>
		 <a href='?page=vimeo_video_links' class="button button-primary"> Add Vimeo Video </a>
		 <h2>Vimeo Video URL List</h2>
		<table border="1" width="100%">
 			<tr>
 				<th>
	 				Sr. No.
	 			</th>
	 			<th>
	 				Video Title
	 			</th>
	 			<th>
	 				Video Url
	 			</th>
	 			<th>
	 				Video Category
	 			</th>
	 			<th>
	 				Video Description
	 			</th>
	 			<th>
	 				Action
	 			</th>
 			</tr>
 		<?php $i = 1;
 		foreach ($videos as $value) { ?>
	 		<tr>
	 			<td>
	 				<?php 
	 				echo $i; ?>
	 			</td>
	 			<td>
	 				<?php echo $value->title; ?>
	 			</td>
	 			<td>
	 				<a href="<?php echo $value->video_url; ?>"><?php echo $value->video_url; ?></a>
	 			</td>
	 			<td>
	 				<?php echo $value->cat_name; ?>
	 			</td>
	 			<td>
	 				<?php echo $value->video_description; ?>
	 			</td>
	 			<td>
	 				<form action="" method="post">
		 				<input type="hidden" name="video_id" class="video_id button button-primary" value="<?php echo $value->id; ?>">
		 				<input type="submit" class="button button-primary" name="edit" value="edit">
		 				<input type="button" class="delete button button-primary" name="delete" value="Delete">
		 			</form>
	 			</td>
	 		</tr>
 		<?php $i++; } ?>
	 	</table>
	 	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	 	<script>
	 		$(document).ready(function(){
	 			$(".open").on("click", function(){
	 				$(".popup-overlay, .popup-content").addClass("active");
				});

				//removes the "active" class to .popup and .popup-content when the "Close" button is clicked 
				$(".close").on("click", function(){
				  $(".popup-overlay, .popup-content").removeClass("active");
				});


				$(".delete").click(function(){
					var row = $(this).closest("tr");
					var video_id = $(row).find(".video_id").val();	
					var conf = confirm("Are you sure");
					if (conf == true) 
					{
						jQuery.ajax({
				          type:'POST',
				          data:{
				          	action:'delete_video',
				          	video_id:video_id,
				      	},
				          url: "<?php echo admin_url( 'admin-ajax.php' ); ?>",
				          success: function(value) {
				          	//alert(value);
				            location.reload();
				          }
				        });
					}
					
				});
			});
	 	</script>
		<?php 
		if (isset($_POST['edit'])) 
		{
			$video_id = $_POST['video_id'];
			global $wpdb;
	  		$table_name = $wpdb->prefix . "video_urls";
	  		$sql = "SELECT * FROM $table_name WHERE id =".$video_id;
	 		$videos = $wpdb->get_results( $sql );
	 		$videos = $videos[0];	 
			/*print_r($videos);*/
	 		?>
	 		<style>
	 			
				.popup-overlay html{
				  font-family: "Helvetica Neue", sans-serif;
				  width:100%;
				  color:#666666;
				  text-align:center;
				}
				.popup-overlay td.left_closebtn {
				    align-items: right;
				    text-align: right;
				}
				.popup-overlay{
				  /*Hides pop-up when there is no "active" class*/
				  visibility:hidden;
				  position:absolute;
				  background:#ffffff;
				  border:3px solid #666666;
				  width:50%;
				  height:50%;
				  left:25%; 
				}
				.popup-overlay.active{
				  /*displays pop-up when "active" class is present*/
				  visibility:visible;
				  text-align:center;
				  top: 85px;
				}

				.popup-content {
				  /*Hides pop-up content when there is no "active" class */
				 visibility:hidden;
				}

				.popup-content.active {
				  /*Shows pop-up content when "active" class is present */
				  visibility:visible;
				}

				.popup-overlay button{
				  display:inline-block;
				  vertical-align:middle;
				  border-radius:30px;
				  margin:.20rem;
				  font-size: 1rem;
				  color:#666666;
				  background:   #ffffff;
				  border:1px solid #666666;  
				}

				.popup-overlay button:hover{
				  border:1px solid #666666;
				  background:#666666;
				  color:#ffffff;
				}

	 		</style>
	 		<div class="popup-overlay active">
			  <!--Creates the popup content-->
			   <div class="popup-content active">
			   	<table width="100%"><tr><td>Update Video</td><td class='left_closebtn'><button class="close">Close</button></td></tr></table>
			     <form method="post" action="">
	 			<input type="hidden" name="row_id" id="row_id" value="<?php echo $videos->id; ?>">
				<table width="100%">
					<tr>
						<th>Video TITLE :</th>
						<td><input type="text" name="title" id="title" placeholder="Enter video title" required="required" value="<?php echo $videos->title; ?>"></td>
					</tr>
					<tr>
						<th>Video URL :</th>
						<td><input type="text" name="video_url" id="video_url" placeholder="Enter video url" required="required" value="<?php echo $videos->video_url; ?>"></td>
					</tr>
					<tr>
						<th>Video Category :</th>
						<td><select name="category" id="category">
							<option value="">--select category--</option>
							<?php 
								if(category_list()){
									foreach(category_list() as $cat){
										?><option value="<?php echo $cat->id; ?>" <?php echo ($cat->id == $videos->cat_id)?"selected":''; ?>><?php echo $cat->name; ?></option><?php
									}
								}
							?>

						</select></td>
					</tr>
					<tr>
						<th>Description :</th>
						<td><textarea rows="8" cols="50" name="description" id="description" placeholder="Enter description"><?php echo $videos->video_description; ?></textarea></td>
					</tr>
				</table>
				<input id="add_video" type="button" class="button button-primary" name="add_video" value="Update Video">
			</form>
			          </div>
			</div>
			<!--Content shown when popup is not displayed-->
			


	 		
			<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
			<script>
				$(document).ready(function(){
					$("#add_video").click(function(){
						//alert("hello");
						var title = $("#title").val();
						var row_id = $("#row_id").val();
						var video_url = $("#video_url").val();
						var category = $("#category").val();
						var description = $("#description").val();
						jQuery.ajax({
				          type:'POST',
				          data:{
				          	action:'my_action',
				          	title:title,
				          	video_url:video_url,
				          	description:description,
				          	category:category,
				          	row_id:row_id,
				      },
				          url: "<?php echo admin_url( 'admin-ajax.php' ); ?>",
				          success: function(response) {
				            //console.log(response);
				            setTimeout(function(){ location.reload(); }, 1000);
				            //location.reload();
				          }
				        });
					});

				});	
			</script>
		<?php
			
		}
	}
	add_action( 'wp_ajax_delete_video', 'delete_video' );
	add_action( 'wp_ajax_nopriv_delete_video', 'delete_video' );
	function delete_video() 
	{
		global $wpdb;
		$table_name = $wpdb->prefix . "video_urls";
		$video_id = $_POST['video_id'];
		$result = $wpdb->delete( $table_name, array( 'id' => $video_id ) );
		//print_r($result);
	}

	add_action( 'wp_ajax_my_action', 'my_action' );
	add_action( 'wp_ajax_nopriv_my_action', 'my_action' );
	function my_action() {
		global $wpdb;
		$table_name = $wpdb->prefix . "video_urls";
		$title = $_POST['title'];
		$video_url = $_POST['video_url'];
		$category = $_POST['category'];
		$description = $_POST['description'];
		$row_id = $_POST['row_id'];
		$thumb = grab_vimeo_thumbnail($video_url);
		$data = array( 
						'title' => $title,	// string
						'video_url' => $video_url,	// integer (number) 
						'video_thumb' => $thumb,	// integer (number) 
						'video_description' => $description,	// integer (number) 
						'cat_id' => $category,	// integer (number) 
					); 
		$where = array( 'id' => $row_id );
		$result = $wpdb->update( $table_name, $data, $where);
		//print_r($data);
	}

	function grab_vimeo_thumbnail($vimeo_url){
	    if( !$vimeo_url ) return false;
	    $data = json_decode( file_get_contents( 'http://vimeo.com/api/oembed.json?url=' . $vimeo_url ) );
	    if( !$data ) return false;
	    return $data->thumbnail_url;
	}
	/********save contact********/
	/*add_action( 'rest_api_init', function () {
		register_rest_route( 'mapi', '/th', array(
			'methods' => 'GET',
			'callback' => 'craete_thumbnail',
		) );
	} );
	function craete_thumbnail(){

		$vimeo_url = "https://vimeo.com/203495611";

		return grab_vimeo_thumbnail($vimeo_url);

	}*/
	/********save contact********/
	add_action( 'rest_api_init', function () {
		register_rest_route( 'mapi', '/save_contacts', array(
			'methods' => 'POST',
			'callback' => 'save_contacts',
		) );
	} );
	function save_contacts($params)
	{
		$data = $params->get_params();

		$content = "some text here";
		$fp = fopen(dirname( __FILE__ )."/myText.txt","wb");
		fwrite($fp,print_r($data,true));
		fclose($fp);
		return $data;


		
	}

	/*********** update user contact **********************/
	add_action( 'rest_api_init', function () {
		register_rest_route( 'mapi', '/update_contact', array(
			'methods' => 'POST',
			'callback' => 'update_contact',
		) );
	} );
	function update_contact($params){

		global $wpdb;
		$contactus_table = $wpdb->prefix."contact";
		$data = $params->get_params();
		$id = $data['id'];
		$name = $data['name'];
		$number = $cont_mobile = preg_replace('/[A-Za-z-!@#$%^&*(), .?":{}|<>]/', '', $data['number']);

		$email = ($data['email']) ? $data['email'] :' ';
		$lastname = ($data['lastname']) ? $data['lastname'] :' ';
		
		$data_arr = array('name'=>$name,'lastname'=>$lastname,'contact'=>$number,'email'=>$email, 'updated_at'=>current_time( 'mysql' ));
		$where = array('id'=>$id);
		$result = $wpdb->update($contactus_table, $data_arr, $where, $format = null, $where_format = null );
		
		if($result == 1){

			$record = $wpdb->get_results("SELECT * FROM $contactus_table WHERE id=".$id); 
			$show['status'] = 'ok';
			$show['message'] = 'contact updated!';
			$show['data'] = $record;
			return $show;

		}else{
			$show['status'] = 'false';
			$show['message'] = 'Error in updation!';
			$show['data'] = array();
			return $show;
		}
	}
	/********************** update status ************************/
	add_action( 'rest_api_init', function () {
		register_rest_route( 'mapi', '/update_status', array(
			'methods' => 'POST',
			'callback' => 'update_status',
		) );
	} );

	function update_status($params){
		
		$data = $params->get_params();
		$user_id = $data['user_id']; 
		$number = $data['number']; 
		$status = $data['status']; 
		return update_contact_status($user_id, $number, $status);
		
	}
	function update_contact_status($user_id, $number, $status){
		global $wpdb;
		$contactus_table = $wpdb->prefix."contact";
		if($user_id && $number && $status){

			$res = $wpdb->update( $contactus_table, array('status'=>$status),array('user_id'=>$user_id,'contact'=>$number), $format = null, $where_format = null ); 	
			if($res){

				$show['status'] = 'ok';	
				$show['message'] = 'successfully updated';	
				return $show;

			}else{

				$show['status'] = 'failed';	
				$show['message'] = 'not updated';	
				return $show;
			}

		}else{

			$show['status'] = 'failed';	
			$show['message'] = 'Please fill all the fields';	
			return $show;
		}
	}


	/*************** tracking data *******************/
	add_action( 'rest_api_init', function () {
		register_rest_route( 'mapi', '/view_history', array(
			'methods' => 'POST',
			'callback' => 'view_history',
		) );
	} );

	function view_history($params){
		$data = $params->get_params();
		$user_id = $data['user_id'];
		$contact = $data['number'];
		return views_history_by_user_contact($user_id, $contact);

	}

	function views_history_by_user_contact($user_id, $contact){
		global $wpdb;	
		$tracking = $wpdb->prefix."user_tracking";
		if($user_id && $contact){
			$result = $wpdb->get_results("SELECT * FROM $tracking WHERE `user_id`=$user_id AND `viewer_contact`=`$contact`");
			if($result){
				$show['status'] = 'ok';	
				$show['message'] = 'data found!';	
				$show['data'] = $result;	
				return $show;
			}else{
				$show['status'] = 'failed';	
				$show['message'] = 'data not found!';	
				$show['data'] = array();	
				return $show;
			}

		}else{
			$show['status'] = 'failed';	
			$show['message'] = 'please send all required fields';	
			$show['data'] = array();	
			return $show;
		}

	}
	/*************** save all contact *******************/
	add_action( 'rest_api_init', function () {
		register_rest_route( 'mapi', '/save_cont', array(
			'methods' => 'POST',
			'callback' => 'save_cont',
		) );
	} );
	function save_cont($params){

			global $wpdb;
			$contactus_table = $wpdb->prefix."contact";
			$data = $params->get_params();
			$user_id = $data['user_id'];	
			$contacts = $data['contacts'];
			$last = array();

			
			foreach($contacts as $data)
			{
				$cnum = $data['number'];
				$cont_mobile = preg_replace('/[A-Za-z-!@#$%^&*(), .?":{}|<>]/', '',$cnum );
				$data_arr = array( 
					        'user_id' => $user_id, 
					        'name'  => $data['name'],
					        'lastname'  => ($data['lastname']) ?$data['lastname']:'',
					        'email'     => ($data['email'])? $data['email']:'',
					        'contact'     => $cont_mobile,
					        'created_at'  => current_time( 'mysql' ),
					        'updated_at'  => current_time( 'mysql' )
				    ) ;
				$sql = "SELECT * FROM  $contactus_table WHERE `contact`='$cont_mobile' AND `user_id`=".$user_id;
				$count = $wpdb->get_results($sql);

				if(!empty($count)){
					$last[] = $wpdb->update($contactus_table, $data_arr, array('contact' => $cont_mobile,'user_id' =>$user_id));
				}else{
					$last[] = $wpdb->insert( $contactus_table, $data_arr);
				}	
			}

			if($last){
				$show['status'] = 'ok';	
				$show['message'] = 'successfully inserted';	
				$show['count'] = count($last);	
				return $show;

			}else{

				$show['status'] = 'false';	
				$show['message'] = 'not inserted';	
				$show['count'] = '';	
				return $show;
			}


	}

	/***************** select all contact user based ************/
	add_action( 'rest_api_init', function () {
		register_rest_route( 'mapi', '/get_contacts', array(
			'methods' => 'POST',
			'callback' => 'get_contacts',
		) );
	} );

	function get_contacts($params){
		global $wpdb;
			$data = $params->get_params();
			$contactus_table = $wpdb->prefix."contact";
			$user_id = $data['user_id'];
			$sql = "SELECT * FROM  $contactus_table WHERE `user_id` =".$user_id;

			$results = $wpdb->get_results($sql);
			if($results){
				$show->status = "ok";
				$show->message = "contacts found!";
				$show->data = $results;
				return $show;
			}else{
				$show->status = "failed";
				$show->message = "contacts not found!";
				$show->data = array();
				return $show;
			}	
	}

	/***************** create short url ************/
	add_action( 'rest_api_init', function () {
		register_rest_route( 'mapi', '/create_short_url', array(
			'methods' => 'POST',
			'callback' => 'create_short_url',
		) );
	} );
	function create_short_url($params){
		
		$tdgn = $params->get_params();

	    $vid = $tdgn['vid'];
		$uid = $tdgn['uid'];
		$cid = $tdgn['cid'];
		$msg = $tdgn['msg'];		
		$video_primary_id = $tdgn['video_primary_id'];
		
		if($vid && $uid && $cid && $video_primary_id){
			return genrate_short_url($vid, $uid, $cid, $msg, $video_primary_id);
		}else{
			$show['status'] = 'failed';
			$show['message'] = 'Please send all required data';
			$show['shorturl'] = ' ';
			return $show;	
		}
	}
	function genrate_short_url($vid, $uid, $cid, $msg, $video_primary_id){
		global $wpdb;
		$si = $vid.'1'.$uid.'1'.$cid; 
	    $shorturl = $site_url.'/video?si='.$si;	
	    $table = $wpdb->prefix.'shorturl';
		$count = $wpdb->get_results("SELECT * FROM  $table WHERE si ='$si'");	
		if(!$count){

			global $wpdb;
			$wpdb->insert($table,array('si' => $si,'video_primary_id'=>$video_primary_id,'shorturl' => $shorturl,'msg' => $msg,'vid' => $vid,'uid' => $uid,'cid' => $cid,'created_at' => current_time( 'mysql' )	),array('%s','%s','%s','%s','%s','%s','%s','%s') 
			);	

			$show['status'] = 'ok';
			$show['message'] = 'successfully created';
			$show['shorturl'] = $si;
			$show['message2'] =get_option( 'stp_api_settings' )['stp_api_text_field_1'];
			return $show;

		}else{

			$show['status'] = 'failed';
			$show['message'] = 'already exists';
			$show['shorturl'] = $si;
			$show['message2'] = get_option( 'stp_api_settings' )['stp_api_text_field_1'];
			return $show;
		}
	}

	/***************** select single contact user based ************/
	add_action( 'rest_api_init', function () {
		register_rest_route( 'mapi', '/get_single_contact', array(
			'methods' => 'POST',
			'callback' => 'get_single_contact',
		) );
	} );
	function get_single_contact($params){

		global $wpdb;
		$table = $wpdb->prefix."contact";
		$data = $params->get_params();
		$id = $data['id']; 

		$sql = "SELECT * FROM  $table WHERE `id` =".$id;
		$result = $wpdb->get_results($sql);
		if($result){
			$show['status'] = 'ok';
			$show['message'] = 'Data Found';
			$show['data'] =$result;
			return $show;
		}else{
			$show['status'] = 'failed';
			$show['message'] = 'Data not Found';
			$show['data'] =array();
			return $show;
		}
	}

	/***************** delete contact user based ************/
	add_action( 'rest_api_init', function () {
		register_rest_route( 'mapi', '/delete_single_contact', array(
			'methods' => 'POST',
			'callback' => 'delete_single_contact',
		) );
	} );
	function delete_single_contact($params){

		global $wpdb;
		$table = $wpdb->prefix."contact";
		$data = $params->get_params();
		$id = $data['id']; 

		$where = array('id'=>$id);
		$deleted = $wpdb->delete( $table, $where, $where_format = null );
		if($deleted){
			$show['status'] = 'ok';
			$show['message'] = 'Data deleted';
			return $show;
		}else{
			$show['status'] = 'ok';
			$show['message'] = 'Data not able to delete';
			return $show;
		}

	}
	/*****all vimeo videos*****/
	add_action( 'rest_api_init', function () {
		register_rest_route( 'mapi', '/all_vimeo_videos', array(
			'methods' => 'POST',
			'callback' => 'mobile_videos_data',
		) );
	} );
	function mobile_videos_data($params)
	{
		$data = $params->get_params();
		$cat_id = $data['cat_id'];
		if($cat_id){
			$videos = all_vimeo_videos_cat($cat_id);
			if (empty($videos)) 
			{
				$show->status = "failed";
				$show->message = "No video found";
			}
			else
			{
				$show->status = "ok";
				$show->message = "videos found";
				$show->data = $videos;
			}	
			return $show;
			
		}else{
			$show->status = "failed";
			$show->message = "Please send video category";
			return $show;
		}
		
		
	}
	function all_vimeo_videos()
	{
		global $wpdb;
  		$table_name = $wpdb->prefix . "video_urls";
  		$video_category = $wpdb->prefix . "video_category";
 		$videos = $wpdb->get_results( "
 			SELECT $table_name.*, $video_category.id as cat_id, $video_category.name  as cat_name FROM $table_name
 				LEFT JOIN  $video_category ON $table_name.cat_id = $video_category.id;
 			" );
 		return $videos;
 	}
	
	function all_vimeo_videos_cat($cat_id)
	{
		global $wpdb;
  		$table_name = $wpdb->prefix . "video_urls";
  		$video_category = $wpdb->prefix . "video_category";
 		$videos = $wpdb->get_results( "
 			SELECT $table_name.*, $video_category.id as cat_id, $video_category.name  as cat_name FROM $table_name
 				LEFT JOIN  $video_category ON $table_name.cat_id = $video_category.id WHERE $table_name.cat_id=".$cat_id);
 		return $videos;
 	}
	 
	function category_list(){
		global $wpdb;
		$your_db_name = $wpdb->prefix . 'video_category';
		$sql = "SELECT * FROM $your_db_name";
		return $wpdb->get_results($sql);
	} 
	/**
	 * Display a custom menu page
	 */
	function vimeo_videos(){
		global $wpdb;
		$your_db_name = $wpdb->prefix . 'video_urls';
		?>
		<style>
			.add_video td textarea{
				height: auto;
			}
			.add_video td input, .add_video td select{
				font-size: 11pt;
				height: 40px;
				width:280px;
			}
			.add_video th span {
			    float: left;
			}
			.add_video {
			    width: 49%;
			}

		</style>
		<div class="add_video">
			<h2>Add Vimeo Video</h2>
		<form method="post" action="">
			<table width="100%">
				<tr><td>
					<span>Video Title</span> </td><td><input type="text" name="title" placeholder="Enter video title" required="required"></td>
				</tr>
			<tr>
			<td>

			<span>Video URL </span></td><td><input type="text" name="video_url" placeholder="Enter video url" required="required"></td>
			</tr>

			<tr>
			<td>
				<span>Video Category </span></td><td>

				<select name='category'>
					<option value=''>--select category--</option>
					<?php 
						if(!empty(category_list())){
							foreach(category_list() as $cat){

								print_r($cat);
								?><option value="<?php echo $cat->id; ?>"><?php echo $cat->name; ?></option><?php
							}
						}
					?>
				</select>
			</td>
			</tr>

			<tr><td>
			<span>Description </span></td><td><textarea rows="6" cols="42" name="description" placeholder="Enter description"></textarea></td></tr>
			<tr><td colspan="2"><input align="center" type="submit" name="submit" value="Add video"></td></tr>
		</table>
			
		</form>
	</div>
		<?php 
		if (isset($_POST['submit'])) 
		{
			
			$video_url = $_POST['video_url'];
			$title = $_POST['title'];
			$category = $_POST['category'];
			$description = $_POST['description'];
			if (!empty($video_url) && !empty($title) && !empty($category)) 
			{
				$video_thumb = grab_vimeo_thumbnail($video_url);
				$add_data = $wpdb->insert($your_db_name, array(
				    'title' => $title,
				    'video_url' => $video_url,
				    'video_thumb' => $video_thumb,
				    'cat_id' => $category,
				    'video_description' => $description, // ... and so on
				));

				if($add_data==1)
				{
					echo "Video added successfully";
				}
				else
				{
					echo "Something went wrong";
				}
			}
			else
			{
				echo "Please enter video url and video title";
			}
		}
	}
	/*******change text after reset password*******/
	add_action( 'resetpass_form', function()
		{
		    add_filter( 'gettext', 'wpse_gettext', 10, 2 ); 
		});
		function wpse_gettext( $translated_text, $text )
		{
		    // Modify gettext if there's a match
		    switch ( $text )
		    {
		        case 'Your password has been reset' :           
		            remove_filter( current_filter(), __FUNCTION__ );
		            $translated_text = __( 'Your password is created sucessfuly click here to login');
		            break;
		    }  
		    return $translated_text;
		} 
	/*******change new password form***************/
	add_action( 'resetpass_form', function( $user )
		{ ?> <p class="user-wpse-pass2-wrap">
		        <label for="wpse-pass2"><?php _e( 'Confirm new password' ) ?></label><br />
		        <input type="password" name="wpse-pass2" id="wpse-pass2" class="input" 
		               size="20" value="" autocomplete="off" />
		    </p> <?php
		} );
		add_action( 'validate_password_reset', function( $errors )
		{
		    if ( isset( $_POST['pass1'] ) && $_POST['pass1'] != $_POST['wpse-pass2'] )
		        $errors->add( 'password_reset_mismatch', __( 'The password and confirm password do not match.' ) );
		} );

	/*************** Register User ******************/
	add_action( 'rest_api_init', function () {
		register_rest_route( 'mapi', '/register', array(
			'methods' => 'POST',
			'callback' => 'mapi_user_register',
		) );
	} );
	function mapi_user_register($param){
		global $wpdb;
		
		$data = $param->get_params();
		$firstname = sanitize_text_field($data['First_name']);
		$lastname = sanitize_text_field($data['Last_name']);
		$email = $data['Email_address'];
		$Zija_Member_ID = sanitize_text_field($data['Zija_Member_ID']);
		$DeviceTokan = sanitize_text_field($data['DeviceTokan']);
		$phone = sanitize_text_field($data['phone']);
		$privacy_policy = $data['privacy_policy'];
		$terms_condition = $data['terms_condition'];
		$news_letter = $data['news_letter'];
		
		if($firstname && $email && $Zija_Member_ID && $privacy_policy && $terms_condition){
			
			$user_name = $email;			
			//check if the email is not in use yet
			if (!email_exists($email)) {
				$random_password = wp_generate_password(16);
				//create the user 
				$user_id = wp_create_user($user_name, $random_password, $email);
				if (!is_wp_error($user_id)) {				
					$userdata = array(
						"ID" => $user_id,
						"first_name" => $firstname,
						"last_name" => $lastname,
						"display_name" => $firstname.' '.$lastname,
						"role" => "subscriber",
					);

					$user_id = wp_update_user($userdata);
					update_user_meta($user_id,'Zija_Member_ID',$Zija_Member_ID);
					update_user_meta($user_id,'DeviceTokan',$DeviceTokan);
					update_user_meta($user_id,'phone',$phone);
					update_user_meta($user_id,'privacy_policy',$privacy_policy);
					update_user_meta($user_id,'terms_condition',$terms_condition);
					update_user_meta($user_id,'news_letter',$news_letter);
					if(!empty($user_id)){
						$post_id =10;
						$plan_status = get_post_meta($post_id,'pms_subscription_plan_status',true);
						$plan_user_role = get_post_meta($post_id,'pms_subscription_plan_user_role',true);
						
						$plan_price = get_post_meta($post_id,'pms_subscription_plan_price',true);
						$plan_duration = get_post_meta($post_id,'pms_subscription_plan_duration',true);
						$plan_unit = get_post_meta($post_id,'pms_subscription_plan_duration_unit',true);
						
						$start_date = date('Y-m-d H:i:s');
						
						$end_date = ($plan_duration && $plan_unit) ? date('Y-m-d H:i:s', strtotime($Date. ' + '.$plan_duration.' '.$plan_unit)) : '';
						

						$transaction_id = ($data['transaction_id'])?$data['transaction_id']:"";
						$payment_gateway = ($data['payment_gateway'])?$data['payment_gateway'] : '';
						$billing_amount = ($data['billing_amount'])?$data['billing_amount'] :"";
						$status = ($data['status'])?$data['status']:"";
						
						$subscription_table = $wpdb->prefix.'pms_member_subscriptions';
						$sql = "INSERT INTO $subscription_table (`user_id`, `subscription_plan_id`, `start_date`, `expiration_date`, `status`, `payment_profile_id`, `payment_gateway`, `billing_amount`, `billing_duration`, `billing_duration_unit`, `billing_cycles`, `billing_next_payment`, `billing_last_payment`, `trial_end`) VALUES ($user_id,$post_id,'$start_date','$end_date','$status','','$payment_gateway','$billing_amount','','$transaction_id','','','','')";
						$wpdb->query($sql);
						
						$subscription_table2 = $wpdb->prefix.'pms_payments';
						$sql2 = "INSERT INTO $subscription_table2 (`user_id`, `subscription_plan_id`, `status`, `date`, `amount`, `payment_gateway`, `currency`, `type`, `transaction_id`, `profile_id`, `logs`, `ip_address`, `discount_code`) VALUES ($user_id,$post_id,'','$start_date','$billing_amount','','','','','','','','')";
						$wpdb->query($sql2);
						
					}
					mapi_send_password_reset_mail($user_id);					
				}
				$show->status= true;
				$show->message = "User successfully Created!";
				$show->data =get_user_by('id', $user_id)->data;
				return $show;

			}else{
				$show->status= false;
				$show->message = "Email id already exists!";
				$show->data = array();
				return $show;
			}
		}else{
			$show->status= false;
			$show->message = "Please fill all the required fields!";
			$show->data = array();
			return $show;
		}
	}	
		
	/********************* password reset link email *********************/
	function mapi_send_password_reset_mail($user_id){
		$user = get_user_by('id', $user_id);
		$firstname = $user->first_name;
		$email = $user->user_email;
		$adt_rp_key = get_password_reset_key( $user );
		$user_login = $user->user_login;
		$rp_link = '<a href="' . wp_login_url()."?action=rp&key=$adt_rp_key&login=" . rawurlencode($user_login) . '">' . wp_login_url()."/?action=rp&key=$adt_rp_key&login=" . rawurlencode($user_login) . '</a>';
		
		if ($firstname == "") $firstname = "";
		$message = "Hi ".$firstname.",<br>";
		$message .= "An account has been created on ".get_bloginfo( 'name' )." for email address ".$email."<br>";
		$message .= "Click here to set the password for your account: <br>";
		$message .= $rp_link.'<br>';

		//deze functie moet je zelf nog toevoegen. 
	   $subject = __("Your account on ".get_bloginfo( 'name'));
	   $headers = array();

	   add_filter( 'wp_mail_content_type', function( $content_type ) {return 'text/html';});
	   $headers[] = 'From: <wordpress@tdgn.app>'."\r\n";
	   wp_mail( $email, $subject, $message, $headers);

	   // Reset content-type to avoid conflicts -- http://core.trac.wordpress.org/ticket/23578
	   remove_filter( 'wp_mail_content_type', 'set_html_content_type' );
	}	
	
	/*************** update device tokan ****************************/
	add_action( 'rest_api_init', function () {
		register_rest_route( 'mapi', '/update_tokan', array(
			'methods' => 'POST',
			'callback' => 'update_tokan',
		) );
	} );
	function update_tokan($params){
		$data = $params->get_params();
		$new_tokan =$data['DeviceTokan'];
		$user_id = $data['user_id'];
		if($user_id && $new_tokan){
			$update = update_user_meta($user_id,'DeviceTokan',$new_tokan);
			if($update){
				$empty_data_array->status = true;
				$empty_data_array->message = 'tokan updated successfully';
				return $empty_data_array;
			}else{
				$empty_data_array->status = false;
				$empty_data_array->message = 'Tried to update with same value';
				return $empty_data_array;
			}
		}else{
			$empty_data_array->status = false;
			$empty_data_array->message = 'please fill all required fields';
			return $empty_data_array;
		}
	}
	
	/******************************** login user *************************/
	add_action( 'rest_api_init', function () {
		register_rest_route( 'mapi', '/login_user', array(
			'methods' => 'POST',
			'callback' => 'login_user',
		) );
	} );
	function login_user($params){
		$data = $params->get_params();
		$email = $data['email'];
		$password = $data['password'];
		$creds = array(
			'user_login'    => $email,
			'user_password' => $password,
			'remember'      => true
		);
	 
		$user = wp_signon( $creds, false );
	 
		if ( is_wp_error( $user ) ) {
			$show->status = false;
			$show->message = explode('.',strip_tags($user->get_error_message()))[0];
			$show->data =array();
		}else{
			$show->status=true;
			$show->message="successfully logged in!";
			$show->data= $user->data;	
						
		}
		return $show;
	}
	/************** update password **********************/
	add_action( 'rest_api_init', function () {
		register_rest_route( 'mapi', '/update_password', array(
			'methods' => 'POST',
			'callback' => 'update_password',
		) );
	} );
	function update_password($params){
		$data = $params->get_params();
	
		$user_id = $data['user_id'];
		$oldpassword = $data['old_password'];
		$newpassword = $data['new_password'];
		
		if($user_id && $oldpassword && $newpassword){
			
			$userdata = get_user_by('ID', $user_id);
			$result = wp_check_password($oldpassword, $userdata->user_pass, $userdata->ID);
			if($result == true){
				wp_set_password( $newpassword, $user_id );
				$empty_data_array->status = true;
				$empty_data_array->message = 'Password updated successfully';
				return $empty_data_array;
			}else{
				$empty_data_array->status = false;
				$empty_data_array->message = 'Old password not matched!';
				return $empty_data_array;
			}
			
		}else{
			
			$empty_data_array->status = false;
			$empty_data_array->message = 'please fill all required fields';
			return $empty_data_array;
			
		}	
	}
	
	/************** Forget password **********************/
	add_action( 'rest_api_init', function () {
		register_rest_route( 'mapi', '/forget_password', array(
			'methods' => 'POST',
			'callback' => 'forget_password',
		) );
	} );
	function forget_password($params){
		$data = $params->get_params();	
		$email = $data['email'];
		$userdata = get_user_by('email', $email);
		if($userdata != false){
		
			mapi_send_password_reset_mail($userdata->data->ID);
			$show->status =true;
			$show->message ='Please check '.$email.' and reset your password by clicking on the reset password link!';
			return $show;
			
		}else{
			
			$empty_data_array->status = false;
			$empty_data_array->message = 'User with email '.$email.' not found!';
			return $empty_data_array;			
		}		
	}
	
	/************** get user info **********************/
	add_action( 'rest_api_init', function () {
		register_rest_route( 'mapi', '/get_contact_list_of_user', array(
			'methods' => 'POST',
			'callback' => 'get_contact_list_of_user',
		) );
	} );
	function get_contact_list_of_user($params){
		global $wpdb; 
		$data = $params->get_params();
		$user_id = $data['user_id'];
		$filter = $data['filter'];
		$sort_by = $data['sort_by'];
		$contact = $wpdb->prefix.'contact';	
		$user_tracking = $wpdb->prefix.'user_tracking';	
		$user_tracking_meta = $wpdb->prefix.'user_tracking_meta';	
		
		$sql = "SELECT c.*, COALESCE(MAX(tm.created_at),'') as last_viewed FROM `$contact` as c left join $user_tracking as ut ON ut.viewer_contact= c.contact left join $user_tracking_meta as tm ON ut.si=tm.si WHERE c.user_id=$user_id";
		
		if($filter){
			$sql .=" AND c.status='".$filter."'";
		}
		$sql .=" GROUP BY c.contact";
		
		if($sort_by && $sort_by != 'recent_activity'){
			$sql .= " ORDER BY c.".$sort_by." ASC";			
		}
		
		if($sort_by && $sort_by == 'recent_activity'){
			$sql .= " ORDER BY last_viewed DESC";			
		}

		/*return $sql;*/

		$dat = $wpdb->get_results($sql);
		if($dat){
			
			$show->status = 'ok';
			$show->message = 'Contacts found';
			$show->data = $dat;
			return $show;
			
		}else{
			
			$show->status = 'ok';
			$show->message = 'Contacts not found';
			$show->data = array();
			return $show;
			
		}
	}


	/************** get user info **********************/
	add_action( 'rest_api_init', function () {
		register_rest_route( 'mapi', '/get_contact_history', array(
			'methods' => 'POST',
			'callback' => 'get_contact_history',
		) );
	} );
	function get_contact_history($params){
		global $wpdb;
		$user_tracking = $wpdb->prefix.'user_tracking';
		$user_tracking_meta = $wpdb->prefix.'user_tracking_meta';
		$contacttb = $wpdb->prefix.'contact';
		$shorturl = $wpdb->prefix.'shorturl';
		$video_urls = $wpdb->prefix.'video_urls';
		$data = $params->get_params();
		$user_id = $data['user_id'];
		$contact = $data['contact'];
		$status = $data['status'];
		
		if($user_id && $contact){
			
			$sql = "SELECT wc.name as firstname, wc.lastname as lastname, sturl.shorturl as url, MAX(utm.created_at) as activity_date, ut.status as contact_status, IF(ut.status, CONCAT(wc.name,' requested a call back'), CONCAT(vurl.title,' Viewd and left')) as status,sturl.created_at as sent_date, MAX(utm.view_time) as view_time FROM $user_tracking as ut LEFT JOIN $contacttb as wc ON wc.contact=ut.viewer_contact LEFT JOIN $user_tracking_meta as utm ON utm.si=ut.si LEFT JOIN $shorturl as sturl ON sturl.si=ut.si LEFT JOIN $video_urls as vurl ON vurl.id = sturl.video_primary_id WHERE ut.user_id=".$user_id." AND ut.viewer_contact='$contact'";	

			if($status){
				$sql .= " AND wc.status='$status'";
			}			
			$sql .= " GROUP BY url";
			
			/*return $sql;*/
			$data = $wpdb->get_results($sql);
			if($data){
				$show->status = 'ok';
				$show->message = 'History Found';
				$show->data = $data;
				return $show;
				
			}else{
				
				$show->status = 'failed';
				$show->message = 'NO records found';
				$show->data = array();
				return $show;
				
			}
		}		
	}
	
	/************ single video full history ********************/
	add_action( 'rest_api_init', function () {
		register_rest_route( 'mapi', '/single_video', array(
			'methods' => 'POST',
			'callback' => 'single_video',
		) );
	} );
	function single_video($params){
		global $wpdb;
		$data = $params->get_params();
		$si = $data['si'];
		$user_tracking = $wpdb->prefix.'user_tracking';
		$user_tracking_meta = $wpdb->prefix.'user_tracking_meta';
		$contacttb = $wpdb->prefix.'contact';
		$shorturl = $wpdb->prefix.'shorturl';
		$video_urls = $wpdb->prefix.'video_urls';

		$sql = "SELECT  wc.name as firstname, wc.lastname as lastname, sturl.shorturl as url, ut.status as contact_status, IF(ut.status, CONCAT(wc.name,' requested a call back'), CONCAT(vurl.title,' Viewd and left')) as status, utm.view_time, utm.created_at as activity_date, sturl.created_at as sent_date FROM $user_tracking as ut LEFT JOIN $contacttb as wc ON wc.contact=ut.viewer_contact LEFT JOIN $user_tracking_meta as utm ON utm.si=ut.si LEFT JOIN $shorturl as sturl ON sturl.si=ut.si LEFT JOIN $video_urls as vurl ON vurl.id = sturl.video_primary_id WHERE ut.si=$si";
		
		$result = $wpdb->get_results($sql);
		if($result){
			
			$show->status = 'ok';
			$show->message = 'data found';
			$show->data = $result;
			return $show;
			
		}else{
			
			$show->status = 'failed';
			$show->message = 'data not found';
			$show->data = array();
			return $show;			
		}
	} 
	
	/************** User alerts **********************/
	add_action( 'rest_api_init', function () {
		register_rest_route( 'mapi', '/alerts', array(
			'methods' => 'POST',
			'callback' => 'alerts',
		) );
	} );
	function alerts($params){
		$data = $params->get_params();
		$user_id = $data['user_id'];
		return alert_list($user_id);
	
	}

	function alert_list($user_id){
		global $wpdb;
		$table = $wpdb->prefix.'user_tracking';
		$user_tracking_meta = $wpdb->prefix.'user_tracking_meta';
		$contact = $wpdb->prefix.'contact';
		$video_urls = $wpdb->prefix.'video_urls';
		/*LEFT JOIN $user_tracking_meta as utm ON ut.si = utm.si */

		$sql = "SELECT ut.*, MAX(utm.created_at) as activity_date, COALESCE(ct.name,'') as firstname, COALESCE(ct.lastname,'') as lastname, IF(ut.status, CONCAT(COALESCE(ct.name,''),' viewed ', vu.title ,' and requested call back'),CONCAT(COALESCE(ct.name,''),' viewed ', vu.title ,' video and left')) as status 
			FROM $table as ut
			LEFT JOIN $contact as ct ON ct.contact=ut.viewer_contact
			LEFT JOIN $user_tracking_meta as utm ON utm.si=ut.si
			LEFT JOIN $video_urls as vu ON CONCAT('https://vimeo.com/',ut.video_vimeo_id)=vu.video_url
			WHERE `ut`.`user_id` = ".$user_id." GROUP BY ut.si";

		$result = $wpdb->get_results($sql);
		if($result){
			
			$show->status = 'ok';
			$show->message = 'data found';
			$show->data = $result;
			return $show;
			
		}else{
			
			$show->status = 'failed';
			$show->message = 'data not found';
			$show->data = array();
			return $show;			
		}
	}


	/************** get user info **********************/
	add_action( 'rest_api_init', function () {
		register_rest_route( 'mapi', '/update_user_data', array(
			'methods' => 'POST',
			'callback' => 'update_user_data',
		) );
	} );
	function update_user_data($params){
		global $wpdb;
		$data = $params->get_params();
		$user_id = $data['user_id'];
		$email = $data['email'];
		$Zija_Member_ID = $data['Zija_Member_ID'];
		$last_name = $data['last_name'];
		$first_name = $data['first_name'];
		$phone = $data['phone'];
		$privacy_policy = $data['privacy_policy'];
		$terms_condition = $data['terms_condition'];
		$news_letter = $data['news_letter'];
		$table = $wpdb->prefix.'users';
		$check = email_exists($email);
		$res = 0;
		$em;
		if(!$check){
			$em = "email already exists";
			$res = $wpdb->update($table, array('user_login' => $email,'user_email'=>$email), array('ID' => $user_id));
		}
		if($first_name){
			$first_name = update_user_meta($uid,'first_name', $first_name);
		}
		if($last_name){
			$last_name = update_user_meta($uid,'last_name', $last_name);
		}
		if($Zija_Member_ID){
			$Zija_Member_ID = update_user_meta($uid,'Zija_Member_ID', $Zija_Member_ID);
		}		
		if($privacy_policy ){
			$privacy_policy = update_user_meta($uid,'privacy_policy', $privacy_policy);
		}
		if($terms_condition){
			$terms_condition = update_user_meta($uid,'terms_condition', $terms_condition);
		}
		if($news_letter){
			$news_letter = update_user_meta($uid,'news_letter', $news_letter);
		}
		if($phone){
			$phone = update_user_meta($uid,'phone', $phone);
		}

		if($res){

			$show->status = 'ok';
			$show->message = 'user updated'.$em;
			
			return $show;

		}else{
			$show->status = 'failed';
			$show->message = 'User not updated';
			return $show;

		}		


	}

	/************** get user info **********************/
	add_action( 'rest_api_init', function () {
		register_rest_route( 'mapi', '/get_news', array(
			'methods' => 'POST',
			'callback' => 'get_news',
		) );
	} );
	function get_news($params){
			$data = $params->get_params();
			$page_no = $data['page_no'];
			$page = ($page_no) ? $page_no :1;

			$args = array(
			  'post_type' => 'post' ,
			  'orderby' => 'date' ,
			  'order' => 'DESC' ,
			  'posts_per_page' => 10,
			  'cat'         => '2',
			  'paged' => $page,
			);

			$ar_total = array(
			  'post_type' => 'post' ,
			  'cat'         => '2',
			);
			$total = count(get_posts($ar_total));

			$posts = get_posts($args);
			if($posts){
				$all_posts = array();
				foreach($posts as $post){

					if (has_post_thumbnail( $post->ID ) ){
					   $post->featured_image = wp_get_attachment_url( get_post_thumbnail_id( $post->ID ));
					}else{
						$post->featured_image = '';
					}
					$all_posts[] = $post;
				}
				$show->status = "ok";
				$show->total = $total;
				$show->message = "Posts found";
				$show->data = $all_posts;

			}else{

				$show->status = "failed";
				$show->message = "Posts not found";
				$show->data = array();
			}	
			return $show;
	}


	/************** get user info **********************/
	add_action( 'rest_api_init', function () {
		register_rest_route( 'mapi', '/send_notification', array(
			'methods' => 'POST',
			'callback' => 'send_notification',
		) );
	} );

	function send_notification($params){
		$data = $params->get_params();
		$user_id = $data['user_id'];
		return send_notification_for_changestatus($user_id);
	}

	function send_notification_for_changestatus($user_id){
		$tokenList = tokenList(array($user_id));
		return send_notification_device($tokenList);
	}
	function tokenList($uids){
		$tokenList = array();
		foreach ($uids as $id) {
			$DeviceTokan = get_user_meta($id,'DeviceTokan',true);
			if($DeviceTokan){
				$tokenList[] = $DeviceTokan;
			} 
		}
		return $tokenList;		 
	}

	function send_notification_device($tokenList){
		if($tokenList){

			define('API_ACCESS_KEY','AAAAUCGok8g:APA91bHOwQzle0oG1N2NAkC2YAeJ8MhnwlmPyAlffF9EKlluoV7ZcH8KA_3-IRhuZtG1N2h9jzINfRzBLcvQ4LHzBZIPK50r-cIj-ndqvr1SSNiFs0-jOcuWAQ62FWqff_VeTNZPbzrm');

			$fcmUrl = 'https://fcm.googleapis.com/fcm/send';
		 		  $notification = [
		            'title' =>'Someone Requested Call Back',
		            'body' => 'Some on requested you to call back now',
		            'icon' =>'1', 
		            'sound' => '1'
		        ];
		        $extraNotificationData = ["message" => $notification,"moredata" =>'dd'];

		        $fcmNotification = [
		            'registration_ids' => $tokenList, //multple token array
		            //'to'        => $token, //single token
		            'notification' => $notification,
		            'data' => $extraNotificationData
		        ];

		        $headers = [
		            'Authorization: key=' . API_ACCESS_KEY,
		            'Content-Type: application/json'
		        ];


		        $ch = curl_init();
		        curl_setopt($ch, CURLOPT_URL,$fcmUrl);
		        curl_setopt($ch, CURLOPT_POST, true);
		        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
		        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fcmNotification));
		        $result = curl_exec($ch);
		        curl_close($ch);
		        echo $result;
		}else{
			$show->status = 'failed';
			$show->message = 'device tokan not found';
			return $show;	
		} 
	}
	/************** get user info **********************/
	add_action( 'rest_api_init', function () {
		register_rest_route( 'mapi', '/message_placeholders', array(
			'methods' => 'GET',
			'callback' => 'message_placeholders',
		) );
	} );
	function message_placeholders(){
		$show->status = "ok";	
		$show->message = array('message'=>get_option( 'stp_api_settings' )['stp_api_text_field_0'],"message2"=>get_option( 'stp_api_settings' )['stp_api_text_field_1']);
		return $show;
	}
	/************** get user info **********************/
	add_action( 'rest_api_init', function () {
		register_rest_route( 'mapi', '/get_user_info', array(
			'methods' => 'POST',
			'callback' => 'get_user_info_by_user_id',
		) );
	} );
	function get_user_info_by_user_id($params){
		$data = $params->get_params();
		$user_id = $data['user_id'];
		if($user_id){
			
			$user = get_user_by( 'ID', $user_id);
			$uid = $user->data->ID;
			if($uid){

				$first_name = get_user_meta($uid,'first_name', true);
				$last_name = get_user_meta($uid,'last_name', true);
				$Zija_Member_ID = get_user_meta($uid,'Zija_Member_ID', true);
				$privacy_policy = get_user_meta($uid,'privacy_policy', true);
				$terms_condition = get_user_meta($uid,'terms_condition', true);
				$news_letter = get_user_meta($uid,'news_letter', true);
				$phone = get_user_meta($uid,'phone', true);
				$user->data->first_name = $first_name;
				$user->data->last_name = $last_name;
				$user->data->Zija_Member_ID = $Zija_Member_ID;
				$user->data->privacy_policy = $privacy_policy;
				$user->data->terms_condition = $terms_condition;
				$user->data->news_letter = $news_letter;
				$user->data->phone = $phone;
				$show->status = 'ok';
				$show->message = 'user detail';
				$show->data = $user->data;
				return $show;

			}else{
				$show->status = 'failed';
				$show->message = 'User not found';
				$show->data = array();
				return $show;

			}	
		}else{
			$show->status = 'failed';
			$show->message = 'please send user id';
			$show->data = array();
			return $show;
		}

	}

	add_action( 'user_new_form', 'crf_admin_registration_form' );
	function crf_admin_registration_form( $operation ) {

		/*if ( 'add-new-user' !== $operation ) {
			// $operation may also be 'add-existing-user'
			return;
		}*/

		$privacy_policy = ! empty( $_POST['privacy_policy'] ) ? intval( $_POST['privacy_policy'] ) : '';
		$terms_condition = ! empty( $_POST['terms_condition'] ) ? intval( $_POST['terms_condition'] ) : '';
		$news_letter = ! empty( $_POST['news_letter'] ) ? intval( $_POST['news_letter'] ) : '';

		?>
		<table class="form-table">
			<tr>
				<th><label for="privacy_policy"><?php esc_html_e( 'Privacy Policy', 'crf' ); ?></label>
				 <span class="description"><?php esc_html_e( '(required)', 'crf' ); ?></span></th>
				<td>
					<input type="checkbox"
				       id="privacy_policy"
				       name="privacy_policy"
				       value="1" <?php echo ($privacy_policy)?'checked':'';?>
				       class="regular-text"
					/>
				</td>
			</tr>
		</table>
		<table class="form-table">
			<tr>
				<th><label for="privacy_policy"><?php esc_html_e( 'Terms Condition', 'crf' ); ?></label>
				 <span class="description"><?php esc_html_e( '(required)', 'crf' ); ?></span></th>
				<td>
					<input type="checkbox"
				       id="terms_condition"
				       name="terms_condition"
				       value="1" <?php echo ($terms_condition)?'checked':'';?>
				       class="regular-text"
					/>
				</td>
			</tr>
		</table>
		<table class="form-table">
			<tr>
				<th><label for="news_letter"><?php esc_html_e( 'News Letter', 'crf' ); ?></label>
				 
				<td>
					<input type="checkbox"
				       id="news_letter"
				       name="news_letter"
				       value="1" <?php echo ($news_letter)?'checked':'';?>
				       class="regular-text"
					/>
				</td>
			</tr>
		</table>
		<?php
	}
	add_action( 'user_register', 'crf_user_register' );
	function crf_user_register( $user_id ) {
		if ( ! empty( $_POST['privacy_policy'] ) ) {
			update_user_meta( $user_id, 'privacy_policy', intval( $_POST['privacy_policy'] ) );
		}

		if ( ! empty( $_POST['terms_condition'] ) ) {
			update_user_meta( $user_id, 'terms_condition', intval( $_POST['terms_condition'] ) );
		}

		if ( ! empty( $_POST['news_letter'] ) ) {
			update_user_meta( $user_id, 'news_letter', intval( $_POST['news_letter'] ) );
		}
	}
	
	function new_modify_user_table( $column ) {
		$column['Zija_mem_id'] = 'Zija Member ID';
		return $column;
	}
	add_filter( 'manage_users_columns', 'new_modify_user_table' );

	function new_modify_user_table_row( $val, $column_name, $user_id ) {
		switch ($column_name) {
			case 'Zija_mem_id' :
				return get_user_meta($user_id,'Zija_Member_ID',true);
				break;
			default:
		}
		return $val;
	}
	add_filter( 'manage_users_custom_column', 'new_modify_user_table_row', 10, 3 );

	/*settings message page***/

	add_action( 'admin_menu', 'stp_api_add_admin_menu' );
	add_action( 'admin_init', 'stp_api_settings_init' );

	function stp_api_add_admin_menu(  ) {
	    add_options_page( 'Settings API', 'Settings API', 'manage_options', 'settings-api-page', 'stp_api_options_page' );
	}

	function stp_api_settings_init(  ) {
	    register_setting( 'stpPlugin', 'stp_api_settings' );
	    add_settings_section(
	        'stp_api_stpPlugin_section',
	        __( 'Message Text', 'wordpress' ),
	        'stp_api_settings_section_callback',
	        'stpPlugin'
	    );

	    add_settings_field(
	        'stp_api_text_field_0',
	        __( 'First Message', 'wordpress' ),
	        'stp_api_text_field_0_render',
	        'stpPlugin',
	        'stp_api_stpPlugin_section'
	    );

	    add_settings_field(
	        'stp_api_select_field_1',
	        __( 'Second Message', 'wordpress' ),
	        'stp_api_select_field_1_render',
	        'stpPlugin',
	        'stp_api_stpPlugin_section'
	    );
	}

	function stp_api_text_field_0_render(  ) {
	    $options = get_option( 'stp_api_settings' );
	    ?>
	    <textarea rows="8" cols="50" name='stp_api_settings[stp_api_text_field_0]'><?php echo $options['stp_api_text_field_0']; ?></textarea>
	    <?php
	}

	function stp_api_select_field_1_render(  ) {

		$options = get_option( 'stp_api_settings' );
	    ?>
	    <textarea rows="8" cols="50" name='stp_api_settings[stp_api_text_field_1]'><?php echo $options['stp_api_text_field_1']; ?></textarea>
	    <?php
	   }

	function stp_api_settings_section_callback(  ) {
	    echo __( 'Mobile App Message Text ', 'wordpress' );
	}

	function stp_api_options_page(  ) {
	    ?>
	    <form action='options.php' method='post'>
	        <?php
	        settings_fields( 'stpPlugin' );
	        do_settings_sections( 'stpPlugin' );
	        submit_button();
	        ?>

	    </form>
	    <?php
	}